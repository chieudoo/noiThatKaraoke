<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gioithieu extends Model
{
    protected $table = "gioithieu";
    protected $fillable = [];
}
