<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lienhe extends Model
{
    protected $table = "lienhe";
    protected $fillable = [];
}
